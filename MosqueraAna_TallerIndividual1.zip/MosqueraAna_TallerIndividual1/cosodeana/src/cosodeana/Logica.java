package cosodeana;

import processing.core.PImage;

public class Logica {
	
	private Main app;
	private int fuerza=5;
	private int resistencia=-5;
	private int posx,posy;
	private int pantalla=1;
	
	public PImage inicio, instrucciones, juego, azul, rojo;
	
	public Logica(Main app) {
		this.app=app;
		this.posx=250;
		this.posy=250;
		
		inicio= app.loadImage("\\Taller 1\\inicio.png");
		instrucciones= app.loadImage("\\Taller 1\\instrucciones.png");
		juego= app.loadImage("\\Taller 1\\juegito.png");
		azul= app.loadImage("\\Taller 1\\azul.png");
		rojo= app.loadImage("\\Taller 1\\rojo.png");
		
	}
	
	public void pintar() {
		
		switch (pantalla) {
			
		case 1:
			app.image(inicio,0,0);
			
			if(app.mouseY>=420 && app.mouseY<=520 && app.mouseX>=200 && app.mouseX<=300) {
			
				pantalla=2;
			}
			break;
		case 2:
			app.image(instrucciones,0,0);
			
			if(app.mouseY>=420 && app.mouseY<=520 && app.mouseX>=330 && app.mouseX<=430) {
				
				pantalla=3;
			}
			break;
			
		case 3:
			app.image(juego,0,0);
			
			app.ellipseMode(app.CENTER);
			app.fill(255);
			app.ellipse(posx,posy,50,50);
			app.noStroke();
			
			if(posx>=450) {
				pantalla=4;
			}

			if(posx<=50) {
				pantalla=5;
			}
		break;
		
		case 4:
			app.image(rojo,0,0);
			
			if(app.mouseY>=420 && app.mouseY<=520 && app.mouseX>=330 && app.mouseX<=430) {
				
				pantalla=3;
				
				posx=250;
				posy=250;
			}
		break;
		
		case 5:
			app.image(azul,0,0);
			
			if(app.mouseY>=420 && app.mouseY<=520 && app.mouseX>=330 && app.mouseX<=430) {
				
				pantalla=3;
				
				posx=250;
				posy=250;
			}
			
		break;
		}
	}
	
	public void moverD() {
		if(pantalla==3) {
		posx+=fuerza;
		
		System.out.println("derecha");
		}
	}
	public void moverI() {
		if(pantalla==3) {
		posx+=resistencia;
		
	System.out.println("izquierda");
		}
	}

}
