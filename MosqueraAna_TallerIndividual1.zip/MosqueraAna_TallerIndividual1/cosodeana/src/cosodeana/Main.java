package cosodeana;

import processing.core.PApplet;

public class Main extends PApplet{
	
	private Logica log;
	private PApplet app;
	
	public static void main(String[] args) {
		PApplet.main("cosodeana.Main");

	}
	
	public void settings() {
		size(500,500);
	}
	
	public void setup() {
		
		log= new Logica(this);
		
	}
	
	public void draw() {
		log.pintar();
	}
	
	public void keyPressed() {
		if(keyCode==RIGHT) {
			
			log.moverD();
			
		}
		if(keyCode==LEFT) {
			log.moverI();
		}
		
	}

}
